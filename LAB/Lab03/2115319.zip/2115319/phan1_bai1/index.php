<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phan1_bai1</title>
</head>

<body>
    <?php
    $x = 10;
    $y = 7;
    $add = $x + $y;
    $sub = $x - $y;
    $mul = $x * $y;
    $div = $x / $y;
    $mod = $x % $y;
    echo $x . " + " . $y . " = " . $add . "<br>";
    echo $x . " - " . $y . " = " . $sub . "<br>";
    echo $x . " * " . $y . " = " . $mul . "<br>";
    echo $x . " / " . $y . " = " . $div . "<br>";
    echo $x . " % " . $y . " = " . $mod . "<br>";

    ?>
</body>

</html>